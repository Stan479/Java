import java.io.Serializable; // il faut importer serializable avant
// se qu'on implement dans la classe mere l'est aussi dans la classe fille
public abstract class Figure implements Serializable,Cloneable {
	/*Attributs*/
	private String nom;
	// private static final long serialVersionUID = 1L; // pour la serialisation
	/*Constructeur*/
	public Figure(String nom) {
		this.nom = nom;
	}
	
	/*
	 * Methodes
	 */
		
	public String getNom() {
		return nom;
	}
	public void afficher() {
		System.out.println(toString());
	}
	
	public abstract String toString();
	
	public abstract void translater (double dx,double dy); 
	// toutes les figures se translate
	
	public Figure clone() { 
		Figure F = null;
		try { 
			F = (Figure)super.clone();
			F.nom = new String(nom); 
			// le string n'est pas un type primitif, il faut le cloner 'manuellement'
		}
		catch(CloneNotSupportedException e){}
		return F;
	}
	// pour passer la methode clone en public 
	// car elle en protected par defaut
	
}
