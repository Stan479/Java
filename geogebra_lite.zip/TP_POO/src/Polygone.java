import java.util.ArrayList;
public class Polygone extends Figure {
	
	private ArrayList<Point> points = new ArrayList<Point>();
	
	public Polygone (String nom,Point ...points) {
		super(nom);
		for (Point p : points) {
			this.points.add(p);
		}
	}
	
	public Polygone (Point ...points) {
		super(null);
		for (Point p : points) {
			this.points.add(p);
		}
	}
	
	public Polygone (ArrayList<Point> p) {
		super(null);
		points.addAll(p);
	}
	// faudrait mettre une condition un polygone c au moins 3 points
	
	public Polygone (String nom,ArrayList<Point> p) {
		super(nom);
		points.addAll(p);
	}
	
	public void translater(double dx,double dy) {
		for(Point p : points) {
			p.translater(dx, dy);
		}
	}
	
	public String toString() {
		String txt = getNom() + ", ";
		for(Point p : points) {
			txt += p.toString();
		}
		return txt;
	}
	
	public Point getCentre() {
		double x = 0,y = 0;
		for (Point p : points) {
			x += p.getX();
			y += p.getY();
		}
		int nb_points = points.size();
		return new Point(x/nb_points,y/nb_points);
	}
	
	public boolean add(Point new_p) {
		for (Point p : points) {
			if (p.equals(new_p)) {
				return false;
			}
		}
		return points.add(new_p);
	}
	
/*	public Polygone clone() {
		Polygone p = null;
		try {// je peut tenter un truc avec les constructeur
			p = (Polygone)super.clone();
			System.out.println(p);
		}
		catch(Exception e) {
		}
		return p;
	}
*/
	public Polygone clone() {
		ArrayList<Point> pts = new ArrayList<Point>();
		pts.addAll(points); // rajoute tout points � pts
		String nom = new String(getNom());
		Polygone p = new Polygone(nom,pts);
		return p;
	}
	
	public boolean equals(Polygone p) {
		if (points.size() != p.points.size()) {
			return false;
		}
		return true;
		// copier coller solution du cours
		// ou le refaire manuellement
		
	}
	
}
