
public class Segment extends Figure {
	
	private Point p1;
	private Point p2;
	
	// Constructeurs
	
	public Segment(Point p1,Point p2) {
		super(null);
		this.p1 = p1;
		this.p2 = p2;
	}
	
	public Segment(String nom,Point p1,Point p2) {
		super(nom);
		this.p1 = p1;
		this.p2 = p2;
	}
	
	
	
	public Point getCentre() { // == getCenter
		String nom_centre = "centre_" + getNom();
		double cx = (p1.getX() + p2.getX())/2;
		double cy = (p1.getY() + p2.getY())/2;
		Point centre = new Point(nom_centre,cx,cy);
		return centre;
	}
	
	// Methodes 
	
	public double getLongueur () {
		return p1.distance(p2);
	}
	
	public void translater(double dx, double dy) {
		p1.translater(dx, dy);
		p2.translater(dx, dy);
	}
	
	public String toString() {
		String s1 = p1.toString();
		String s2 = p2.toString();
		return getNom()+ " : ("+s1+") , (" + s2 + ")";
	}
	
	// POUR LES EQUALS : c plus simple de renvoyer directement le resultat du test.
	
	public boolean equals(Segment s) { 
		if ((p1.equals(s.p1) && p2.equals(s.p2)) || (p1.equals(s.p2) && p2.equals(s.p1))) {
			// faut verifier dans les deux sens
			// �a sera plus compliquer pour les polygones, faudra reutiliser le equal des segments qui le constitue
			return true;
		}
		return false;
	}
	
	/* public Segment clone() {
		Point a = p1.clone();
		Point b = p2.clone();
		Segment s = new Segment(getNom(),a,b);
		return s;
	} */
	
	public Segment clone() {
		Segment s = null;
		try {
			s = (Segment)super.clone();
			s.p1 = p1.clone();
			s.p2 = p2.clone();
		}
		catch(Exception e) {}
		return s;
	}
		

	
}
