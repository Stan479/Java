
public class SegmentNomme extends Segment implements Nomme{

	public SegmentNomme(Point p1, Point p2) {
		super(p1,p2);
	}
	/* l'ide demandait un constructeur mais il n'en demandait pas pour
	 * NommePoint*/
	public String getNom() {
		String s = toString();
		String[] array = s.split(","); // format toString nom,(p1),(p2)
		return array[0];
	}
}
