import javax.swing.*;
import java.awt.*;
public class test_swing {
	public static void main(String[] args) {
		JFrame fenetre = new JFrame();
		fenetre.setSize(new Dimension(200,300));
		JPanel pan = new JPanel();
		JLabel lab = new JLabel("test");
		JPanel pan1 = new JPanel();
		pan1.setBackground(Color.blue);
		//pan.setBackground(Color.blue);
		pan.setLayout(new BorderLayout());
		pan.add(lab);
		pan.add("South",new JLabel("task"));
		fenetre.setContentPane(pan);
		fenetre.setVisible(true);
	}
}
