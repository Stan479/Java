
public class Point extends Figure{ // pour que Point herite de Figure
	/*
	 * Attributs
	 */
	private double x;
	private double y;
	/*
	 * Constructeur
	 */
	public Point(String n,int xi,int yi) {
		super(n); //pour initialiser nom en utilisant le constructeurs de la classe mere
		x = xi;
		y = yi;
	}
	
	public Point(double x,double y) {
		super(null);
		this.x = x;
		this.y = y;
	}
	
	public Point(String nom,double x,double y) {
		super(nom);
		this.x = x;
		this.y = y;
	}
	
	public Point() {
		super(null);
		x = 0;
		y = 0;
	}
	public Point(Point p) {
		// il faudrait creer un nom different pour ne pas les confondre 
		// genre A' mais si je creer plusieur point a partir de A j'aurais plein de A'
		// faudrait envisager de rajouter un compteur de "point fils" pour qu'ils ai un nombre de ' different
		// super(p.getNom()+"'");
		super(p.getNom());
		x = p.x;
		y = p.y;
	}
	/*
	 * Methodes
	 */
	
	public double distance (Point p) {
		double dx = x - p.x;
		dx = Math.floor(dx); //Math.floor == partie entiere
		double dy = y - p.y;
		dy = Math.floor(dy);
		return Math.sqrt(dx*dx + dy*dy); // application theoreme pythagore	
	}
	
	public String toString() {
		return getNom() +",( "+ x +" ; "+ y+" )";
	}
	
	public void translater(double dx, double dy ) {
		x += dx;
		y += dy;
	}
	
	public double getX( ) {
		return x;
	}
	
	public double getY( ) {
		return y;
	}
	
	public boolean equals(Point p) {
		// mieux vaut l'appeller equals pour ecraser le equals deja present dans figure (par defaut)
		if (x == p.x && y == p.y) {
			return true;
		}
		else {
			return false;
		}
		
	}
	
	public Point clone() { 
		Point p = null;
		try { p = (Point)super.clone();}
		catch(Exception e){}
		return p;
	}
	
	/*public Point clone() { 
		Point p = new Point(getNom(),x,y);
		return p;
	} */ 
	// il faut utiliser cloneable, c'est l'objectif de l'exercice
	
}
// revoir le casting

// drawoval pour dessiner les pts