import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;

public class Editeur {
	ArrayList<Figure> figures;
	
	public void Editeur() {
		
	}
	
	public static void main(String[] args) {
		
	}
}

// faudra utiliser les fonction draw pour les fonction paint
// drawline pour les segments
// drawfilloval pour les segments