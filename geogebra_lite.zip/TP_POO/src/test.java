import java.io.ObjectOutputStream;
import java.util.ArrayList;

import javax.swing.*;

import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.awt.*;
import java.io.FileInputStream;

public class test {
	public static void main(String[] args) {
		System.out.println("hello world");
		JFrame frame = new JFrame("Ma fenetre") ; 
		// Taille de la fen�tre 
		frame.setSize(300,200) ; 
		// On rend la fen�tre visible 
		frame.setVisible(true) ;
		JPanel panel = new JPanel();
		frame.setContentPane(panel);
		JPanel nord = new JPanel();
		nord.setBackground(null);
		panel.add("East",nord);
		panel.setBackground(Color.red);
		nord.setBackground(Color.blue);
		// faut importer color
		nord.setPreferredSize(new Dimension(100,100));
		// faut importer dimension, mais �a marche pas
		nord.add(new Button("hey"));
		// les localisation east, north,... marchent pas,�a centre par defaut
		
		
	}
	public static void print(String txt) {
		System.out.println(txt);
	}
	public static void testPoint() {
		print("\nTest Point \n");
		Figure p1 = new Point(2,3);
		p1.afficher();
		Point p2 = new Point("A",0,0);
		p2.afficher();
		Point p3 = new Point(p2);
		p3.translater(3,4);
		p3.afficher();
		p1.translater(-2,-3);
		System.out.println("distance  entre p3 et p2 : " + p3.distance(p2));
		System.out.println("p1 egal p2 : " + p2.equals(p1)); // marche pas car type reel different ?
		p3.translater(-3,-4);
		p3.afficher();
		System.out.println("p3 egal p2 : " + p2.equals(p3)); 
		//pk �a marche pas, en fait avant p1 �tait de type Figure et quand je l'ai mis en Point �a a marcher
		// la fonction equals marche quand les deux sont des points (le type reel)
		// PS : on peut faire p.x avec une methode dans la classe point quand pour un autre objet
		Point p4 = p2.clone();
		print("\ntest clonage");
		p4.afficher();
		p2.afficher();
		p2.translater(12,-3);
		p2.afficher();
		p4.afficher();
		
		
}
	
	public static void testSegment() {
		print("\nTest Segment \n");
		Point p1 = new Point(0,0);
		Point p2 = new Point(2,2);
		Point p3 = new Point(2,3);
		Segment s1 = new Segment("s1",p1,p2);
		Segment s2 = new Segment("s2",p2,p1);
		s1.afficher();
		print("longueur : " + s1.getLongueur());
		print("centre : " + s1.getCentre());
		s1.translater(12,-4);
		s1.afficher();
		print("s1 equal s2 : " + s1.equals(s2)); 
		// sa marche toujours apres la translation car ils ont les memes points
		// faudrait donner de point different pour avoir false;
		s2 = new Segment(p1,p3);
		print("s1 equal s2 : " + s1.equals(s2)); 
		print("\ntestclonage");
		Segment s = s1.clone();
		s1.translater(12, 23);
		print("clone : " + s.toString());
		print("original translater :" + s1.toString());
	}
	
	public static void testCercle() {
		print("\nTest Cercle \n");
		Point p1 = new Point(0,0);
		Cercle c1 = new Cercle(p1,12);
		Cercle c2 = c1.clone();
		c1.afficher(); 
		c1.translater(2, 3);
		c1.afficher();
		c2.afficher();
		// demander comment mettre parametre par defaut pour ne pas avoir a ecrire un constructeur avec et sans le nom a chaque fois;
	}
	
	public static void testserialisation(Object o,String nom_fichier) throws Exception {
		FileOutputStream file = new FileOutputStream(nom_fichier);
		// creation fichier 
		ObjectOutputStream os = new ObjectOutputStream(file);
		os.writeObject(o);
		os.close();
		// un try catch est aussi faisable
	}
	
	public static Object deserialisation(String nom_fichier) throws Exception{ 
		// ds le cas ou le type d'objet n'est pas pris en compte
		FileInputStream file = new FileInputStream(nom_fichier);
		ObjectInputStream in = new ObjectInputStream(file);
		Object a = in.readObject();
		in.close();
		return a;
	}
	
	public static void testPolygone() {
		Point pt1 = new Point(12,3);
		Point pt2 = new Point(14,21);
		Point pt3 = new Point(2,3);
		Polygone p = new Polygone(pt1,pt2);
		p.afficher();
		Polygone poly = p.clone();
		p.add(pt3);
		poly.afficher();
		p.afficher();
	}
	
	public static void testStructures( ) {
		ArrayList<Figure> structures = new ArrayList<Figure>();
		Point p1 = new Point("p1",12,21);
		Point p2 = new Point("p2",2,4);
		Point p3 = new Point("p3",4,5);
		Segment s = new Segment("segment",p1,p2);
		Cercle c = new Cercle("cercle",p1,4);
		structures.add(p1);
		structures.add(c);
		structures.add(s);
		structures.add(new Polygone("poly",p1,p2,p3));
		System.out.println(structures);
		for(Figure f : structures) {
			f.afficher();
			f.translater(2, 4);
			f.afficher();
		}
		System.out.println(structures);
	}
}
