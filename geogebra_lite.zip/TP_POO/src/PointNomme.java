
public class PointNomme extends Point implements Nomme{
	
	public String getNom() {
		String s = toString();
		String[] array = s.split(",");  // format toString : nom,(x,y)
		// String[] pour une liste de string, y a pas de type array en java 
		return array[0];
	}
}
