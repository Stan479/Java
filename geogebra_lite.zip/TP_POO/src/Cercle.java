
public class Cercle extends Figure {
	
	private Point centre;
	private double rayon;
	
	public Cercle (String nom,Point centre,double rayon) {
		super(nom);
		this.centre = centre;
		this.rayon = rayon;
	}
	
	public Cercle (Point centre,double rayon) {
		super(null);
		this.centre = centre;
		this.rayon = rayon;
	}
	
	public Cercle (Point p1, Point p2) {
		super("");
		this.centre = p1;
		this.rayon = p1.distance(p2);
	}
	
	public Point getCentre() { 
		return centre;
	}
	
	public void translater(double dx,double dy) {
		centre.translater(dx,dy);
	}
	
	public String toString() {
		return getNom() + " : " + centre.toString() + ", " + rayon;
	}
	
	public boolean equals(Cercle c) {
		return centre.equals(c.centre) && rayon == c.rayon;
	}
	
	// peut etre une une methode changeRayon ?
	
	/* public Cercle clone() {
		Point a = centre.clone();
		Cercle c = new Cercle(getNom(),a,rayon);
		return c;
	} */
	
	public Cercle clone() {
		Cercle c = null;
		try {
			c = (Cercle)super.clone();
			c.centre = centre.clone();
		}
		catch (Exception e) {}
		return c;
	}
}



