
public interface Nomme {
	public abstract String getNom();
}
